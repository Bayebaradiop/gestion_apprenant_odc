<?php
require_once __DIR__ . '/../enums/vers_page.php';
use App\Enums\vers_page;
require_once vers_page::VIEW_ERREUR->value;

